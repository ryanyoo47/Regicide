Ryan's Regicide — one-tap install (iPhone)

1) Host these files (GitHub Pages, Netlify, Cloudflare Pages, Vercel). Any static host works.
2) Open the site in Safari on iPhone.
3) Tap Share → Add to Home Screen → Add.

GitHub Pages quick setup:
- Create a public repo, upload all files from this folder.
- Settings → Pages → Deploy from a branch → Branch: main, Folder: /root
- Wait ~1 min; open the URL it shows.
- Add to Home Screen from Safari to install.

Files included:
- index.html — the game
- manifest.webmanifest — PWA manifest (name, icons)
- sw.js — service worker for offline play
- icons/icon-192.png, icons/icon-512.png — app icons
